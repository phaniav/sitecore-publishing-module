﻿(function (Speak) {

    Speak.pageCode(["publishingUtils", "publishingConstants", "publishingShared"],
        function (Utils, Constants, Shared) {
            var updateControls = function (data) {
                var activeData = data.Active,
                    queuedData = data.Queued,
                    recentData = data.Recent;

                Shared.toggleOverviewMessageBar.call(this, data);
                Shared.maintenanceCheck.call(this);

                Utils.setTranslations(this.ListControlActiveJobs.ColumnDefinitionItems);

                Utils.parseData(activeData, { appendTranslations: true });
                Utils.parseData(queuedData);
                Utils.parseData(recentData);

                this.ListControlActiveJobs.reset(activeData);
                this.ListControlQueuedJobs.reset(queuedData);
                this.ListControlRecentJobs.reset(recentData);

                var recentJobsRows = document.querySelectorAll("[data-sc-id='ListControlRecentJobs']")[0].getElementsByClassName("sc-listcontrol-item");

                for (var i = 0; i < recentJobsRows.length; i++) {
                    recentJobsRows[i].setAttribute("data-job-id", recentData[i].Id);
                }

                var queuedJobsRows = document.querySelectorAll("[data-sc-id='ListControlQueuedJobs']")[0].getElementsByClassName("sc-listcontrol-item");

                for (var pos = 0; pos < queuedJobsRows.length; pos++) {
                    queuedJobsRows[pos].setAttribute("data-job-id", recentData[pos].Id);
                }

                if (typeof this.ButtonFullRePublish != 'undefined') {
                    if (this.MessageBar.HasErrorMessages) {
                        this.ButtonFullRePublish.IsEnabled = false;
                    } else {
                        this.ButtonFullRePublish.IsEnabled = true;
                    }
                }
            };

            return {
                initialized: function () {
                    Shared.loadOverviewData.call(this, updateControls);

                    Shared.registerHandlebarList();

                    var dashboard = this;

                    this.SubAppRendererJobDetails.DialogWindow.on("hide",
                        function () {
                            dashboard.ListControlRecentJobs.SelectedItem = null;
                        });

                    this.SubAppRendererFullRePublish.DialogWindow.on("hide",
                        function (event) {
                            Shared.loadOverviewData.call(dashboard, updateControls);
                        },
                        this);

                    this.ListControlRecentJobs.on("change:ClickedItem",
                        function (job) {
                            Shared.jobSelected.apply(dashboard, [job]);
                        });

                    this.ListControlQueuedJobs.on("change:ClickedItem",
                        function (job) {
                            Shared.jobSelected.apply(dashboard, [job]);
                        });
                }
            };
        });

})(Sitecore.Speak);